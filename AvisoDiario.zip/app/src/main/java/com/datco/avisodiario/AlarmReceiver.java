package com.datco.avisodiario;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Scheduler.schedule(c);
        c.startForegroundService(new Intent(c, AlarmService.class));
    }
}
