package com.datco.avisodiario;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Messages {

    public static final String[] DIAS = {"domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"};
    public static final String[] MESES = {"enero", "febrero", "marzo", "abril", "mayo", "junio", "julio",
            "agosto", "septiembre", "octubre", "noviembre", "diciembre"};

    // Arma el texto completo que dirá la voz (usa internet para el clima, llamar fuera del hilo principal)
    public static String build(Context c) {
        Calendar cal = Calendar.getInstance();
        StringBuilder sb = new StringBuilder();
        int hora = cal.get(Calendar.HOUR_OF_DAY);
        sb.append(hora < 12 ? "Buen día. " : hora < 20 ? "Buenas tardes. " : "Buenas noches. ");
        sb.append("Hoy es ").append(DIAS[cal.get(Calendar.DAY_OF_WEEK) - 1]).append(" ")
                .append(cal.get(Calendar.DAY_OF_MONTH)).append(" de ")
                .append(MESES[cal.get(Calendar.MONTH)]).append(" de ")
                .append(cal.get(Calendar.YEAR)).append(". ");

        String w = clima(c);
        if (w != null) sb.append(w).append(" ");

        List<String> pagos = new ArrayList<>();
        List<String> compras = new ArrayList<>();
        for (Store.Item it : Store.load(c)) {
            if (!Store.pendingToday(it, cal)) continue;
            String t = it.nombre;
            if (it.monto != null && !it.monto.trim().isEmpty()) t += " por " + it.monto.trim();
            if ("compra".equals(it.tipo)) compras.add(t); else pagos.add(t);
        }
        if (pagos.isEmpty() && compras.isEmpty()) {
            sb.append("No hay tareas para hoy.");
        } else {
            if (!pagos.isEmpty()) sb.append("Hoy debes pagar ").append(unir(pagos)).append(". ");
            if (!compras.isEmpty()) sb.append("Hoy debes comprar ").append(unir(compras)).append(".");
        }
        return sb.toString().trim();
    }

    static String unir(List<String> l) {
        if (l.size() == 1) return l.get(0);
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            if (i > 0) s.append(i == l.size() - 1 ? " y " : ", ");
            s.append(l.get(i));
        }
        return s.toString();
    }

    static int max(JSONArray a, int from, int to) {
        int m = 0;
        for (int i = from; i <= to && i < a.length(); i++) m = Math.max(m, a.optInt(i, 0));
        return m;
    }

    // Clima de Open-Meteo (gratis, sin clave). Devuelve null si no hay ubicación o internet.
    static String clima(Context c) {
        double[] loc = Store.location(c);
        if (loc == null) return null;
        HttpURLConnection con = null;
        try {
            URL u = new URL("https://api.open-meteo.com/v1/forecast?latitude=" + loc[0] + "&longitude=" + loc[1]
                    + "&current=temperature_2m&hourly=precipitation_probability&daily=weather_code"
                    + "&forecast_days=1&timezone=auto");
            con = (HttpURLConnection) u.openConnection();
            con.setConnectTimeout(6000);
            con.setReadTimeout(6000);
            BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
            StringBuilder s = new StringBuilder();
            String ln;
            while ((ln = r.readLine()) != null) s.append(ln);
            r.close();

            JSONObject j = new JSONObject(s.toString());
            long t = Math.round(j.getJSONObject("current").getDouble("temperature_2m"));
            JSONArray pr = j.getJSONObject("hourly").getJSONArray("precipitation_probability");
            int code = j.getJSONObject("daily").getJSONArray("weather_code").optInt(0, 0);

            boolean man = max(pr, 6, 11) >= 50;
            boolean tar = max(pr, 12, 18) >= 50;
            boolean noc = max(pr, 19, 23) >= 50;

            String pron;
            if (code >= 95) {
                pron = "Se esperan tormentas.";
            } else if (man || tar || noc) {
                if (man && tar && noc) {
                    pron = "Se esperan lluvias durante todo el día.";
                } else {
                    List<String> per = new ArrayList<>();
                    if (man) per.add("la mañana");
                    if (tar) per.add("la tarde");
                    if (noc) per.add("la noche");
                    pron = "Se esperan lluvias por " + unir(per) + ".";
                }
            } else if (code == 0) {
                pron = "El cielo estará despejado.";
            } else if (code == 1 || code == 2) {
                pron = "Estará parcialmente nublado.";
            } else if (code == 3) {
                pron = "Estará nublado.";
            } else if (code == 45 || code == 48) {
                pron = "Habrá niebla.";
            } else if ((code >= 71 && code <= 77) || code == 85 || code == 86) {
                pron = "Se esperan nevadas.";
            } else if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) {
                pron = "Podría llover.";
            } else {
                pron = "";
            }
            String tt = t < 0 ? "menos " + (-t) : String.valueOf(t);
            return ("La temperatura es de " + tt + " grados Celsius. " + pron).trim();
        } catch (Exception e) {
            return null;
        } finally {
            if (con != null) con.disconnect();
        }
    }
}
