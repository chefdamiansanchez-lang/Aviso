package com.datco.avisodiario;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class AlarmActivity extends Activity implements AlarmService.Listener {

    private TextView msg;

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF2A211E);
        root.setPadding(dp(24), dp(48), dp(24), dp(32));

        TextView title = new TextView(this);
        title.setText("Aviso Diario");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(0xFFF1E6DF);
        root.addView(title);

        msg = new TextView(this);
        msg.setText("Preparando el aviso...");
        msg.setTextSize(22);
        msg.setTextColor(0xFFF1E6DF);
        msg.setLineSpacing(0f, 1.2f);
        msg.setPadding(0, dp(20), 0, dp(20));
        ScrollView sv = new ScrollView(this);
        sv.addView(msg);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        Button stop = new Button(this);
        stop.setText("Detener");
        stop.setTextSize(20);
        stop.setAllCaps(false);
        stop.setTextColor(0xFFF1E6DF);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFFC0654A);
        g.setCornerRadius(dp(28));
        stop.setBackground(g);
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startService(new Intent(AlarmActivity.this, AlarmService.class)
                        .setAction(AlarmService.ACTION_STOP));
            }
        });
        root.addView(stop, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)));

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        AlarmService.listener = this;
        if (!AlarmService.running) {
            finish();
            return;
        }
        String m = AlarmService.message;
        if (m != null && !m.isEmpty()) msg.setText(m);
    }

    @Override
    protected void onPause() {
        if (AlarmService.listener == this) AlarmService.listener = null;
        super.onPause();
    }

    @Override
    public void onMessage(final String m) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                msg.setText(m);
            }
        });
    }

    @Override
    public void onStopped() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        });
    }
}
