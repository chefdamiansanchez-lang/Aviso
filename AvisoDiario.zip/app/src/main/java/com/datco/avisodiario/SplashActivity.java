package com.datco.avisodiario;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SplashActivity extends Activity {

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF1B2028);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        // Insignia cuadrada con degradado celeste y la letra D
        TextView badge = new TextView(this);
        badge.setText("D");
        badge.setTextSize(52);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setTextColor(0xFFFFFFFF);
        badge.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF007BC7, 0xFF00D2FF});
        g.setCornerRadius(dp(24));
        badge.setBackground(g);
        col.addView(badge, new LinearLayout.LayoutParams(dp(104), dp(104)));

        TextView title = new TextView(this);
        title.setText("DATCO");
        title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(0xFFFFFFFF);
        title.setLetterSpacing(0.35f);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tl.topMargin = dp(26);
        col.addView(title, tl);

        TextView sub = new TextView(this);
        sub.setText("Desarrollo Avanzado de Tecnologías y Códigos Operativos");
        sub.setTextSize(11);
        sub.setTextColor(0xFF8FA3B5);
        sub.setGravity(Gravity.CENTER);
        sub.setLetterSpacing(0.06f);
        sub.setPadding(dp(40), 0, dp(40), 0);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sl.topMargin = dp(10);
        col.addView(sub, sl);

        TextView foot = new TextView(this);
        foot.setText("Diseño de apps... y algo más");
        foot.setTextSize(12);
        foot.setTextColor(0xFF6B7C8C);
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        fl.bottomMargin = dp(40);
        root.addView(foot, fl);

        setContentView(root);

        // Animación de entrada
        View[] vs = {badge, title, sub, foot};
        for (int i = 0; i < vs.length; i++) {
            vs[i].setAlpha(0f);
            vs[i].setTranslationY(dp(18));
            vs[i].animate().alpha(1f).translationY(0f).setStartDelay(150L * i).setDuration(650).start();
        }
        badge.setScaleX(0.85f);
        badge.setScaleY(0.85f);
        badge.animate().scaleX(1f).scaleY(1f).setDuration(650).start();

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(SplashActivity.this, MainActivity.class));
                finish();
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        }, 2600);
    }
}
