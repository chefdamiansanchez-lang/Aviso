package com.datco.avisodiario;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.util.Locale;

public class AlarmService extends Service implements TextToSpeech.OnInitListener {

    public interface Listener {
        void onMessage(String m);
        void onStopped();
    }

    public static volatile Listener listener;
    public static volatile String message = "";
    public static volatile boolean running = false;
    public static final String ACTION_STOP = "com.datco.avisodiario.STOP";

    private static final String CH = "aviso_alarma";
    private static final int ID = 77;
    private static final int MAX_VUELTAS = 8;

    private TextToSpeech tts;
    private boolean ttsReady = false, ttsFailed = false, msgReady = false, started = false;
    private int vueltas = 0;
    private final Handler h = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wl;
    private Ringtone ringtone;

    private final Runnable repetir = new Runnable() {
        @Override
        public void run() {
            hablar();
        }
    };

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAll();
            return START_NOT_STICKY;
        }
        if (started) return START_NOT_STICKY;
        started = true;
        running = true;
        message = "";

        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CH, "Aviso diario", NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(null, null);
        nm.createNotificationChannel(ch);

        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, AlarmActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, AlarmService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification n = new Notification.Builder(this, CH)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Aviso Diario")
                .setContentText("Reproduciendo el aviso de hoy")
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(true)
                .setContentIntent(open)
                .setFullScreenIntent(open, true)
                .addAction(0, "Detener", stop)
                .build();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(ID, n);
        }

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "avisodiario:alarma");
        wl.acquire(10 * 60 * 1000L);

        tts = new TextToSpeech(this, this);

        new Thread(new Runnable() {
            @Override
            public void run() {
                final String m = Messages.build(AlarmService.this);
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        if (!running) return;
                        message = m;
                        msgReady = true;
                        Listener l = listener;
                        if (l != null) l.onMessage(m);
                        trySpeak();
                    }
                });
            }
        }).start();

        return START_NOT_STICKY;
    }

    @Override
    public void onInit(int status) {
        if (!running || tts == null) return;
        if (status != TextToSpeech.SUCCESS) {
            ttsFailed = true;
            trySpeak();
            return;
        }
        int r = tts.setLanguage(new Locale("es", "AR"));
        if (r < 0) r = tts.setLanguage(new Locale("es", "ES"));
        if (r < 0) r = tts.setLanguage(new Locale("es"));
        if (r < 0) {
            ttsFailed = true;
            trySpeak();
            return;
        }
        tts.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build());
        tts.setSpeechRate(0.95f);
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String id) {
            }

            @Override
            public void onDone(String id) {
                if (running) h.postDelayed(repetir, 20000);
            }

            @Override
            public void onError(String id) {
                if (running) h.postDelayed(repetir, 20000);
            }
        });
        ttsReady = true;
        trySpeak();
    }

    private void trySpeak() {
        if (!running) return;
        if (ttsFailed) {
            tonoDeRespaldo();
            return;
        }
        if (ttsReady && msgReady) hablar();
    }

    private void hablar() {
        if (!running || tts == null) return;
        if (vueltas >= MAX_VUELTAS) {
            stopAll();
            return;
        }
        vueltas++;
        tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "aviso" + vueltas);
    }

    // Si el celular no tiene voz en español, suena el tono de alarma común
    private void tonoDeRespaldo() {
        if (ringtone != null) return;
        try {
            Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            ringtone = RingtoneManager.getRingtone(this, u);
            if (ringtone != null) {
                ringtone.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM).build());
                ringtone.play();
            }
        } catch (Exception e) {
            // nada
        }
    }

    private void cleanup() {
        running = false;
        h.removeCallbacksAndMessages(null);
        if (tts != null) {
            try {
                tts.stop();
                tts.shutdown();
            } catch (Exception e) {
                // nada
            }
            tts = null;
        }
        if (ringtone != null) {
            try {
                ringtone.stop();
            } catch (Exception e) {
                // nada
            }
            ringtone = null;
        }
        if (wl != null) {
            try {
                if (wl.isHeld()) wl.release();
            } catch (Exception e) {
                // nada
            }
            wl = null;
        }
    }

    private void stopAll() {
        cleanup();
        Listener l = listener;
        if (l != null) l.onStopped();
        stopForeground(Service.STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }
}
