package com.datco.avisodiario;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    static final int BG = 0xFF2A211E, CARD = 0xFF3A2E2A, CARD2 = 0xFF4A3B36;
    static final int TXT = 0xFFF1E6DF, SUB = 0xFFBFA99D, ACC = 0xFFC0654A;
    static final int MP = ViewGroup.LayoutParams.MATCH_PARENT, WC = ViewGroup.LayoutParams.WRAP_CONTENT;

    private LinearLayout content;
    private List<Store.Item> items = new ArrayList<>();

    int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(28), dp(18), dp(40));
        sv.addView(content);
        setContentView(sv);
        pedirPermisos();
    }

    @Override
    protected void onResume() {
        super.onResume();
        items = Store.load(this);
        capturarUbicacion();
        Scheduler.schedule(this);
        render();
    }

    // ---------- Permisos y ubicación ----------

    void pedirPermisos() {
        List<String> p = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            p.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            p.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), 10);
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] perms, int[] res) {
        super.onRequestPermissionsResult(rc, perms, res);
        capturarUbicacion();
        render();
    }

    void capturarUbicacion() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        try {
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            Location best = null;
            String[] provs = {LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER};
            for (String pv : provs) {
                try {
                    Location l = lm.getLastKnownLocation(pv);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                } catch (Exception e) {
                    // siguiente proveedor
                }
            }
            if (best != null) {
                Store.setLocation(this, best.getLatitude(), best.getLongitude());
            } else if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, new LocationListener() {
                    @Override
                    public void onLocationChanged(Location l) {
                        Store.setLocation(MainActivity.this, l.getLatitude(), l.getLongitude());
                        render();
                    }

                    @Override
                    public void onStatusChanged(String provider, int status, Bundle extras) {
                    }

                    @Override
                    public void onProviderEnabled(String provider) {
                    }

                    @Override
                    public void onProviderDisabled(String provider) {
                    }
                }, Looper.getMainLooper());
            }
        } catch (Exception e) {
            // sin ubicación
        }
    }

    // ---------- Ayudas de interfaz ----------

    TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(16));
        l.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MP, WC);
        lp.setMargins(0, dp(6), 0, dp(6));
        l.setLayoutParams(lp);
        return l;
    }

    Button btn(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(TXT);
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinWidth(0);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(24));
        b.setBackground(g);
        return b;
    }

    String cap(String s) {
        return s.substring(0, 1).toUpperCase(Locale.ROOT) + s.substring(1);
    }

    String desc(Store.Item it) {
        String t = "compra".equals(it.tipo) ? "Compra" : "Pago";
        String f;
        if ("mensual".equals(it.freq)) {
            f = "cada mes, día " + it.dia;
        } else if ("semanal".equals(it.freq)) {
            f = "cada " + Messages.DIAS[Math.max(1, Math.min(7, it.dia)) - 1];
        } else {
            String[] p = it.fecha.split("-");
            f = p.length == 3 ? p[2] + "/" + p[1] + "/" + p[0] : "una vez";
        }
        String m = (it.monto == null || it.monto.trim().isEmpty()) ? "" : " · " + it.monto.trim();
        return t + " · " + f + m;
    }

    String proxima() {
        if (!Store.enabled(this)) return "Alarma apagada";
        long t = Scheduler.next(this);
        if (t < 0) return "Elige al menos un día";
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t);
        return String.format(Locale.US, "Próximo aviso: %s %02d:%02d",
                Messages.DIAS[c.get(Calendar.DAY_OF_WEEK) - 1], c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
    }

    // ---------- Pantalla principal ----------

    void render() {
        content.removeAllViews();
        final Calendar hoy = Calendar.getInstance();

        content.addView(tv("Aviso Diario", 28, TXT, true));
        content.addView(tv("Una alarma con voz: fecha, clima y lo que toca hoy", 14, SUB, false));

        // Tarjeta de la alarma
        LinearLayout a = card();
        content.addView(a);

        LinearLayout fila = new LinearLayout(this);
        fila.setGravity(Gravity.CENTER_VERTICAL);
        TextView hora = tv(String.format(Locale.US, "%02d:%02d", Store.hour(this), Store.minute(this)), 46, TXT, true);
        hora.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vv) {
                elegirHora();
            }
        });
        fila.addView(hora, new LinearLayout.LayoutParams(0, WC, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(Store.enabled(this));
        sw.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton bv, boolean on) {
                Store.setEnabled(MainActivity.this, on);
                Scheduler.schedule(MainActivity.this);
                render();
            }
        });
        fila.addView(sw);
        a.addView(fila);

        // Días: la semana empieza en domingo
        final boolean[] dd = Store.days(this);
        String[] et = {"D", "L", "M", "M", "J", "V", "S"};
        LinearLayout dias = new LinearLayout(this);
        dias.setPadding(0, dp(10), 0, dp(4));
        for (int i = 0; i < 7; i++) {
            final int k = i;
            FrameLayout cell = new FrameLayout(this);
            TextView t = tv(et[i], 15, dd[i] ? TXT : SUB, true);
            t.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(dd[i] ? ACC : CARD2);
            t.setBackground(g);
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View vv) {
                    dd[k] = !dd[k];
                    Store.setDays(MainActivity.this, dd);
                    Scheduler.schedule(MainActivity.this);
                    render();
                }
            });
            cell.addView(t, new FrameLayout.LayoutParams(dp(38), dp(38), Gravity.CENTER));
            dias.addView(cell, new LinearLayout.LayoutParams(0, dp(42), 1f));
        }
        a.addView(dias);

        a.addView(tv(proxima(), 14, SUB, false));
        a.addView(tv(Store.location(this) != null ? "Clima: ubicación lista"
                : "Clima: sin ubicación (permite la ubicación para que diga el clima)", 12, SUB, false));

        Button probar = btn("Probar el aviso ahora", CARD2);
        probar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vv) {
                startForegroundService(new Intent(MainActivity.this, AlarmService.class));
            }
        });
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(MP, dp(44));
        pl.topMargin = dp(10);
        a.addView(probar, pl);

        // Hoy
        TextView th = tv("Hoy", 20, TXT, true);
        th.setPadding(0, dp(16), 0, dp(2));
        content.addView(th);
        LinearLayout hc = card();
        content.addView(hc);
        boolean hay = false;
        for (Store.Item it : items) {
            if (Store.pendingToday(it, hoy)) {
                hc.addView(filaItem(it, true, hoy));
                hay = true;
            }
        }
        if (!hay) hc.addView(tv("No hay tareas para hoy", 16, SUB, false));

        // Todos los pagos y compras
        TextView tt = tv("Mis pagos y compras", 20, TXT, true);
        tt.setPadding(0, dp(16), 0, dp(2));
        content.addView(tt);
        LinearLayout lc = card();
        content.addView(lc);
        if (items.isEmpty()) lc.addView(tv("Todavía no cargaste nada", 16, SUB, false));
        for (Store.Item it : items) lc.addView(filaItem(it, false, hoy));

        Button add = btn("+ Agregar pago o compra", ACC);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vv) {
                showForm(null);
            }
        });
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(MP, dp(52));
        al.topMargin = dp(14);
        content.addView(add, al);
    }

    LinearLayout filaItem(final Store.Item it, boolean conHecho, final Calendar hoy) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(8), 0, dp(8));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(tv(it.nombre, 17, TXT, true));
        col.addView(tv(desc(it), 13, SUB, false));
        r.addView(col, new LinearLayout.LayoutParams(0, WC, 1f));
        if (conHecho) {
            Button hb = btn("Hecho", ACC);
            hb.setPadding(dp(18), 0, dp(18), 0);
            hb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View vv) {
                    it.hecho = Store.periodKey(it, hoy);
                    Store.save(MainActivity.this, items);
                    render();
                }
            });
            r.addView(hb, new LinearLayout.LayoutParams(WC, dp(40)));
        } else {
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View vv) {
                    showForm(it);
                }
            });
        }
        return r;
    }

    void elegirHora() {
        new TimePickerDialog(this, R.style.DialogTheme, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(android.widget.TimePicker tp, int h, int m) {
                Store.setTime(MainActivity.this, h, m);
                Store.setEnabled(MainActivity.this, true);
                Scheduler.schedule(MainActivity.this);
                render();
            }
        }, Store.hour(this), Store.minute(this), true).show();
    }

    // ---------- Formulario de pago / compra ----------

    String fmtFecha(int[] f) {
        return String.format(Locale.US, "%02d/%02d/%04d", f[2], f[1] + 1, f[0]);
    }

    void ajustar(Spinner sd, Button bf, int pos, int[] dia) {
        if (pos == 2) {
            sd.setVisibility(View.GONE);
            bf.setVisibility(View.VISIBLE);
            return;
        }
        bf.setVisibility(View.GONE);
        sd.setVisibility(View.VISIBLE);
        String[] opts;
        if (pos == 0) {
            opts = new String[31];
            for (int i = 0; i < 31; i++) opts[i] = "Día " + (i + 1);
        } else {
            opts = new String[7];
            for (int i = 0; i < 7; i++) opts[i] = cap(Messages.DIAS[i]);
        }
        sd.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, opts));
        sd.setSelection(Math.min(dia[0], opts.length) - 1);
    }

    void showForm(final Store.Item existing) {
        final boolean nuevo = existing == null;
        final Store.Item it = nuevo ? new Store.Item() : existing;
        final int[] dia = {it.dia > 0 ? it.dia : 1};
        final int[] f = new int[3];
        if (it.fecha != null && it.fecha.matches("\\d{4}-\\d{2}-\\d{2}")) {
            String[] p = it.fecha.split("-");
            f[0] = Integer.parseInt(p[0]);
            f[1] = Integer.parseInt(p[1]) - 1;
            f[2] = Integer.parseInt(p[2]);
        } else {
            Calendar c0 = Calendar.getInstance();
            f[0] = c0.get(Calendar.YEAR);
            f[1] = c0.get(Calendar.MONTH);
            f[2] = c0.get(Calendar.DAY_OF_MONTH);
        }

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(10), dp(22), 0);

        final RadioGroup rg = new RadioGroup(this);
        rg.setOrientation(LinearLayout.HORIZONTAL);
        RadioButton r1 = new RadioButton(this);
        r1.setText("Pago");
        r1.setId(1001);
        RadioButton r2 = new RadioButton(this);
        r2.setText("Compra");
        r2.setId(1002);
        rg.addView(r1);
        rg.addView(r2);
        rg.check("compra".equals(it.tipo) ? 1002 : 1001);
        box.addView(rg);

        final EditText en = new EditText(this);
        en.setHint("Nombre (ej. ABL, leche)");
        en.setSingleLine(true);
        en.setText(it.nombre);
        box.addView(en);

        final EditText em = new EditText(this);
        em.setHint("Monto (opcional)");
        em.setSingleLine(true);
        em.setText(it.monto);
        box.addView(em);

        final Spinner sf = new Spinner(this);
        sf.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Cada mes", "Cada semana", "Una sola vez"}));
        box.addView(sf);

        final Spinner sd = new Spinner(this);
        box.addView(sd);

        final Button bf = new Button(this);
        bf.setAllCaps(false);
        bf.setText(fmtFecha(f));
        bf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vv) {
                new DatePickerDialog(MainActivity.this, R.style.DialogTheme,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(android.widget.DatePicker dp, int y, int m, int d) {
                                f[0] = y;
                                f[1] = m;
                                f[2] = d;
                                bf.setText(fmtFecha(f));
                            }
                        }, f[0], f[1], f[2]).show();
            }
        });
        box.addView(bf);

        sd.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                dia[0] = pos + 1;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        sf.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                ajustar(sd, bf, pos, dia);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        int fi = "semanal".equals(it.freq) ? 1 : "unica".equals(it.freq) ? 2 : 0;
        sf.setSelection(fi);
        ajustar(sd, bf, fi, dia);

        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.DialogTheme);
        b.setTitle(nuevo ? "Nuevo pago o compra" : "Editar").setView(box)
                .setPositiveButton("Guardar", null)
                .setNegativeButton("Cancelar", null);
        if (!nuevo) {
            b.setNeutralButton("Borrar", new android.content.DialogInterface.OnClickListener() {
                @Override
                public void onClick(android.content.DialogInterface di, int w) {
                    items.remove(existing);
                    Store.save(MainActivity.this, items);
                    render();
                }
            });
        }
        final AlertDialog dlg = b.create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vv) {
                String nom = en.getText().toString().trim();
                if (nom.isEmpty()) {
                    en.setError("Escribe un nombre");
                    return;
                }
                it.tipo = rg.getCheckedRadioButtonId() == 1002 ? "compra" : "pago";
                it.nombre = nom;
                it.monto = em.getText().toString().trim();
                int fp = sf.getSelectedItemPosition();
                it.freq = fp == 0 ? "mensual" : fp == 1 ? "semanal" : "unica";
                it.dia = dia[0];
                it.fecha = String.format(Locale.US, "%04d-%02d-%02d", f[0], f[1] + 1, f[2]);
                if (nuevo) {
                    it.id = String.valueOf(System.currentTimeMillis());
                    items.add(it);
                }
                Store.save(MainActivity.this, items);
                dlg.dismiss();
                render();
            }
        });
    }
}
