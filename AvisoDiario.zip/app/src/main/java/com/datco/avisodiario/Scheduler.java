package com.datco.avisodiario;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import java.util.Calendar;

public class Scheduler {

    public static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getBroadcast(c, 1, new Intent(c, AlarmReceiver.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        long t = Store.enabled(c) ? next(c) : -1;
        if (t < 0) {
            am.cancel(pi);
            return;
        }
        PendingIntent show = PendingIntent.getActivity(c, 2, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(t, show), pi);
    }

    // Próximo momento en que debe sonar (ms), o -1 si no hay días elegidos
    public static long next(Context c) {
        long now = System.currentTimeMillis();
        boolean[] days = Store.days(c);
        for (int i = 0; i <= 7; i++) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, i);
            cal.set(Calendar.HOUR_OF_DAY, Store.hour(c));
            cal.set(Calendar.MINUTE, Store.minute(c));
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            if (cal.getTimeInMillis() > now && days[cal.get(Calendar.DAY_OF_WEEK) - 1]) {
                return cal.getTimeInMillis();
            }
        }
        return -1;
    }
}
