package com.datco.avisodiario;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class Store {

    public static class Item {
        public String id = "";
        public String tipo = "pago";      // pago | compra
        public String nombre = "";
        public String monto = "";
        public String freq = "mensual";   // mensual | semanal | unica
        public int dia = 1;               // mensual: 1-31 | semanal: 1=domingo ... 7=sábado
        public String fecha = "";         // unica: yyyy-MM-dd
        public String hecho = "";         // periodo ya marcado como hecho
    }

    static SharedPreferences p(Context c) {
        return c.getSharedPreferences("aviso_diario", Context.MODE_PRIVATE);
    }

    public static List<Item> load(Context c) {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p(c).getString("items", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.id = o.optString("id");
                it.tipo = o.optString("tipo", "pago");
                it.nombre = o.optString("nombre");
                it.monto = o.optString("monto");
                it.freq = o.optString("freq", "mensual");
                it.dia = o.optInt("dia", 1);
                it.fecha = o.optString("fecha");
                it.hecho = o.optString("hecho");
                out.add(it);
            }
        } catch (Exception e) {
            // lista vacía
        }
        return out;
    }

    public static void save(Context c, List<Item> list) {
        JSONArray a = new JSONArray();
        try {
            for (Item it : list) {
                JSONObject o = new JSONObject();
                o.put("id", it.id);
                o.put("tipo", it.tipo);
                o.put("nombre", it.nombre);
                o.put("monto", it.monto);
                o.put("freq", it.freq);
                o.put("dia", it.dia);
                o.put("fecha", it.fecha);
                o.put("hecho", it.hecho);
                a.put(o);
            }
        } catch (Exception e) {
            // nada
        }
        p(c).edit().putString("items", a.toString()).apply();
    }

    // ---- Alarma ----
    public static int hour(Context c) { return p(c).getInt("hora", 6); }
    public static int minute(Context c) { return p(c).getInt("min", 30); }
    public static boolean enabled(Context c) { return p(c).getBoolean("activa", false); }

    public static void setTime(Context c, int h, int m) {
        p(c).edit().putInt("hora", h).putInt("min", m).apply();
    }

    public static void setEnabled(Context c, boolean on) {
        p(c).edit().putBoolean("activa", on).apply();
    }

    // índice 0 = domingo ... 6 = sábado
    public static boolean[] days(Context c) {
        String s = p(c).getString("dias", "1111111");
        boolean[] d = new boolean[7];
        for (int i = 0; i < 7; i++) d[i] = i < s.length() && s.charAt(i) == '1';
        return d;
    }

    public static void setDays(Context c, boolean[] d) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < 7; i++) s.append(d[i] ? '1' : '0');
        p(c).edit().putString("dias", s.toString()).apply();
    }

    // ---- Ubicación para el clima ----
    public static void setLocation(Context c, double lat, double lon) {
        p(c).edit().putString("lat", String.valueOf(lat)).putString("lon", String.valueOf(lon)).apply();
    }

    public static double[] location(Context c) {
        String a = p(c).getString("lat", null);
        String b = p(c).getString("lon", null);
        if (a == null || b == null) return null;
        try {
            return new double[]{Double.parseDouble(a), Double.parseDouble(b)};
        } catch (Exception e) {
            return null;
        }
    }

    // ---- Qué toca hoy ----
    public static String dateKey(Calendar cal) {
        return String.format(Locale.US, "%04d-%02d-%02d",
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
    }

    public static boolean isDue(Item it, Calendar cal) {
        if ("mensual".equals(it.freq)) {
            int last = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
            return cal.get(Calendar.DAY_OF_MONTH) == Math.min(it.dia, last);
        }
        if ("semanal".equals(it.freq)) {
            return cal.get(Calendar.DAY_OF_WEEK) == it.dia;
        }
        return dateKey(cal).equals(it.fecha);
    }

    public static String periodKey(Item it, Calendar cal) {
        String k = dateKey(cal);
        return "mensual".equals(it.freq) ? k.substring(0, 7) : k;
    }

    public static boolean pendingToday(Item it, Calendar cal) {
        return isDue(it, cal) && !periodKey(it, cal).equals(it.hecho);
    }
}
